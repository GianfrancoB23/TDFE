import React from 'react'

const NoEncontrado = () => {
  return (
    <div>
        <h2>NO SE ENCONTRO PAGINA.</h2>
    </div>
  )
}

export default NoEncontrado